#!/usr/bin/env Rscript

# ICF - Anna Belova - March 2021
# Evaluate changes in suicide cases attributable to future temperature changes
#
# The code is to be run from command line with arguments:
# - Configuration file name
# - Warming degree for which calculations are to be executed
# - Flag for running calculations in point mode or uncertainty mode
# - Flag for whether to assume baseline population or future population for calculations
#
# The code produces
# - Attributable suicide cases by county, age group, sex, climate model

library(progress)
library(tidyverse)   
library(configr)    
library(readxl)
library(lhs)
library(triangle)

setwd(Sys.getenv("PROJECT_LOC"))
DATA_DIR <- Sys.getenv("DATA_LOC")
WORKBOOK_DIR <- Sys.getenv("WORKBOOK_DIR")

SEED = 31416
set.seed(SEED)

DEBUG <- TRUE

#----------Read inputs, process parameters--------

args = commandArgs(trailingOnly=TRUE)

CONFIG          <-  args[1] #"configuration.yaml"
DEGREE          <-  args[2] # "D1" or "D2" or "D3" or "D4" or "D5" or "D6"
POINT_MODE      <-  as.logical(args[3])       # "TRUE" or "FALSE"
POPULATION_YEAR <-  args[4] # "PRESENT" or "FUTURE"

config <- read.config(file=CONFIG)

source("simulate/estimateUtils.R")


print(CONFIG)
print(DEGREE)
print(POINT_MODE)
print(POPULATION_YEAR)

base_climate <- readClimate(DATA_DIR, config$input_data$climate[["BASE"]][["Livneh"]], "Baseline",
                            config$input_data$climate$columns, config$hif_transformations)
population_data  <- readPopulation(DATA_DIR, config$input_data$demographic$population)
incidence_data  <- readIncidence(DATA_DIR, config$input_data$demographic$incidence)

#-------Initiate output files------

OUT_FILE_NAME <- getOutFileHandle( DATA_DIR, config$results_file_names_stubs$cases[[DEGREE]], 
                                  POINT_MODE, POPULATION_YEAR, NA, NA, NA,
                                  format(Sys.time(), format="%Y-%m%d-%H%M%S") , FALSE)
APPEND_FLAG <- FALSE


#-------Define the set of climate models ------

model_set <- c()
for (m in names(config$input_data$climate[[DEGREE]]) )  { 
  if (  config$input_data$climate[[DEGREE]][[m]][["year"]] != "NA" ) {  
      print("")
      print(m)
      print(config$input_data$climate[[DEGREE]][[m]])
      model_set <- c(model_set, m) 
    } 
  }
N_mod <- length(model_set)

#-------Sample parameter sets ---------

hif_names <- names( config$hif_parameters )
hif_param_set <- list()
hif_param_set[["POINT"]] <- list()
hif_param_set[["SAMPLE"]] <- list()

for ( h in hif_names) {
  hif_param_set[["POINT"]][[h]]  <- createValueList(  config$hif_parameters[[h]] , NA )
  
  if ( !(POINT_MODE) ) {
    hif_param_set[["SAMPLE"]][[h]] <- createValueList( config$hif_parameters[[h]] , config$convergence )
  }
}

if ( !(POINT_MODE) ) {
  param_iter_data <- createParamIterData( hif_param_set[["SAMPLE"]], config$convergence )
  write_csv( param_iter_data, paste(OUT_FILE_NAME,"_param_iter.csv",sep="") )
}


if (DEBUG) { print(hif_param_set[["POINT"]]) }
if (DEBUG) { print(hif_param_set[["SAMPLE"]]) }

#-------Loop though climate models ---------

pb <- progress_bar$new(
  format = "  processing [:bar] :percent eta: :eta",
  total = N_mod, clear = FALSE, width= 100)

print(paste("Processing", N_mod, "climate models"))

start_time <- Sys.time()
for (i in 1:N_mod) {
  
  if (DEBUG) { print(model_set[i]) }
  
  # Create input list
  inp_data <- prepInput(readClimate(DATA_DIR, config$input_data$climate[[DEGREE]][[model_set[i]]], model_set[i], 
                                    config$input_data$climate$columns, config$hif_transformations), 
                       base_climate, population_data, incidence_data,  
                       POPULATION_YEAR  )
  
  # Compute cases
  res_data <- computeCases( inp_data, POINT_MODE, hif_param_set, config$convergence )
  
  # Record results
  write_csv( res_data, OUT_FILE_NAME , append = APPEND_FLAG)
  APPEND_FLAG <- TRUE
  
  pb$tick()
}
end_time <- Sys.time()
print(end_time - start_time)

#------ Print summary ----------

res <- read_csv(OUT_FILE_NAME)

if ( POINT_MODE ) {
  
  summ <- res %>% group_by(HIF,MODEL) %>% summarise(cases = sum(CASES_PT)) %>% ungroup() 
  
} else {
  
  summ <- res %>% group_by(HIF,MODEL,ITER) %>% summarise(cases = sum(CASES_ITER)) %>% ungroup() %>% 
    group_by(HIF,MODEL) %>% 
    summarise(MEAN = mean(cases), 
              LCB = quantile(cases,config$convergence$conv_quant$LCB), 
              UCB = quantile(cases,config$convergence$conv_quant$UCB)  )  %>% 
    ungroup() %>%
    gather(stat,cases,MEAN:UCB) 
}

print(summ %>% spread(HIF,cases) )

