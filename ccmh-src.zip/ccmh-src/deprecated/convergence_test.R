library(lhs)

qtile <- c(0.025,0.05,0.5,0.95,0.975)
prev_q_beta1 <- 1 
prev_q_beta2 <- 1 
prev_q_y1 <- 1
prev_q_y2 <- 1

U0 <- optimumLHS(100, 2, maxSweeps = 5, eps = 0.05, verbose = TRUE)
U <- augmentLHS(U0, m = 5900)
beta1 <- qnorm(U[,1],0,2) 
beta2 <- qnorm(U[,2],2,1) 
y1 <- beta1*2 + beta2*5 
y2 <- beta1*3 + beta2*10

S <- 1000

for (S in c(1:100) ) {
  

q_beta1 <- quantile(beta1,qtile)
q_beta2 <- quantile(beta2,qtile)
q_y1 <- quantile(y1,qtile)
q_y2 <- quantile(y2,qtile)

print( ( abs(1 - q_beta1/prev_q_beta1) < 0.1 ) )
print( ( abs(1 - q_beta2/prev_q_beta2) < 0.1 ) )

print("*******")
print( ( abs(1 - q_y1/prev_q_y1) < 0.1 ) )
print( ( abs(1 - q_y2/prev_q_y2) < 0.1 ) )

prev_q_beta1 <- q_beta1 
prev_q_beta2 <- q_beta2 
prev_q_y1 <- q_y1
prev_q_y2 <- q_y2


}

inc <- read_csv("/Users/abelova/ICF/EPA Climate and Mental Health - General/03_Analysis Data and Manuscript/modeling/ccmh-data/processed/mo_dist_suicide_rates_1999_2019.csv")
dd <- read_csv("/Users/abelova/ICF/EPA Climate and Mental Health - General/03_Analysis Data and Manuscript/modeling/ccmh-data/processed/ICLUSv2_InterpCtyPopn_AgeSex_2010-2100.csv")

incidence <- inc %>% mutate(sex=tolower(sex), prob = inc_rate_monthly_per100000 / 100000)
population <- dd %>% filter(year==2015) %>% mutate(sex=tolower(sex))
join <- inner_join(incidence, population, by=c("fips","agegrp","sex"))
join %>% mutate(cases = sex_age_popn * prob) %>% summarise(cases=sum(cases))
join %>% mutate(cases = sex_age_popn * prob) %>% group_by(agegrp) %>% summarise(cases=sum(cases))


res <- read_csv("/Users/abelova/ICF/EPA Climate and Mental Health - General/03_Analysis Data and Manuscript/modeling/ccmh-data/results/D6_Cases_PTMODE-FALSE_POPYR-FUTURE_2021-0514-114422.csv")

res_conv <- list()
for (n in c(400,500)) {
summ <- res %>% filter(ITER <= n) %>% group_by(HIF,MODEL,FIPS,SEX, AGE, ITER) %>% summarise(cases = sum(CASES_ITER)) %>% ungroup() %>% 
  group_by(HIF,MODEL,FIPS,SEX, AGE ) %>% 
  summarise(MEAN = mean(cases), 
            LCB = quantile(cases,0.05), 
            UCB = quantile(cases,0.95)  )  %>% 
  ungroup() %>%
  gather(stat,cases,MEAN:UCB) %>%
  spread(HIF,cases)

print(paste("=================NUM ITER", n))
print(summ)
res_conv[[n]] <- summ
}
res_conv_dat <- bind_rows(res_conv, .id="NITER")

ctest <- function(x0,x1) { abs(1 - x1/x0) < 0.1 }
testing <- res_conv_dat %>% 
  arrange(MODEL,FIPS,SEX, AGE, stat, NITER) %>% 
  group_by(MODEL,FIPS,SEX, AGE, stat)  %>% 
  mutate(tbinned = ctest(binned,lag(binned)),
         tbinned_displ = ctest(binned_displ,lag(binned_displ)),
         tlinear = ctest(linear,lag(linear)),
         tlinear_wprecip = ctest(linear_wprecip,lag(linear_wprecip))) %>%
  ungroup() %>%
  filter(NITER==2)
  
testing %>% group_by(MODEL, stat) %>% summarise(mean(tbinned),mean(tbinned_displ),mean(tlinear),mean(tlinear_wprecip))
