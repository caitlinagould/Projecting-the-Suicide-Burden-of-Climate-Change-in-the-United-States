#!/usr/bin/env Rscript

# ICF - Anna Belova - March 2021
# Estimate value of avoiding suicide cases attributable to future temperature changes
#
# The code is to be run from command line with arguments:
# - Configuration file name (which is pointing to the input file name)
# - Warming degree for which calculations are to be executed
# - Flag for running calculations in point mode or uncertainty mode
# - Discount rate
# - Discount year
#
# The code produces
# - Value of avoiding attributable suicide cases by county, age group, sex, climate model


library(progress)
library(tidyverse)   
library(configr)    
library(readxl)
library(lhs)
library(triangle)

setwd(Sys.getenv("PROJECT_LOC"))
DATA_DIR <- Sys.getenv("DATA_LOC")
WORKBOOK_DIR <- Sys.getenv("WORKBOOK_LOC")

SEED = 31416
set.seed(SEED)

DEBUG <- TRUE


#----------Read inputs, process parameters--------

args = commandArgs(trailingOnly=TRUE)

CONFIG          <-  args[1] #"configuration.yaml"
DEGREE          <-  args[2] # "D1" or "D2" or "D3" or "D4" or "D5" or "D6"
POINT_MODE      <-  as.logical(args[3])       # "TRUE" or "FALSE"
POPULATION_YEAR <-  args[4] # "PRESENT" or "FUTURE"
INCOME_YEAR     <-  args[5] # "PRESENT" or "FUTURE"
DISCOUNT_RATE   <-  as.numeric(args[6])       # 0.03
DISCOUNT_YEAR   <-  as.numeric(args[7])       # 2015

config <- read.config(file=CONFIG)

source("simulate/estimateUtils.R")

print(CONFIG)
print(DEGREE)
print(POINT_MODE)
print(POPULATION_YEAR)
print(INCOME_YEAR)
print(DISCOUNT_RATE)
print(DISCOUNT_YEAR)

vsl_incgf_data  <- readVSL(WORKBOOK_DIR, config$input_workbooks$vsl_income_growth_factors)

#-------Initiate output files------

CASE_FILE_NAME_STUB <- getOutFileHandle( DATA_DIR, config$results_file_names_stubs$cases[[DEGREE]], 
                                   POINT_MODE, POPULATION_YEAR, NA, NA, NA, NA , TRUE )

if (DEBUG) { print(CASE_FILE_NAME_STUB)}

IN_FILE_NAME_SET <- list.files(path = file.path(DATA_DIR,"results"), pattern= CASE_FILE_NAME_STUB )

IN_FILE_NAME_SET <- IN_FILE_NAME_SET[!grepl("_iter.csv",IN_FILE_NAME_SET)]

if (DEBUG) { print(IN_FILE_NAME_SET)}

# If there is more than one results file, take the latest
if ( length(IN_FILE_NAME_SET) > 1) {
  IN_FILE_NAME_SET <- rev(sort(IN_FILE_NAME_SET))
}
IN_FILE_NAME <- file.path(DATA_DIR,"results",IN_FILE_NAME_SET[1])

if (DEBUG) { print(IN_FILE_NAME)}
  
OUT_FILE_NAME <- getOutFileHandle( DATA_DIR, config$results_file_names_stubs$values[[DEGREE]], 
                                         POINT_MODE, POPULATION_YEAR, INCOME_YEAR, DISCOUNT_RATE, DISCOUNT_YEAR,
                                   format(Sys.time(), format="%Y-%m%d-%H%M%S") , FALSE )

#-------Sample parameter sets ---------

vsl_param_set <- list()
vsl_param_set[["POINT"]] <- list()
vsl_param_set[["SAMPLE"]] <- list()
vsl_param_set[["POINT"]][["vsl"]] <- createValueList(  config$vsl_information$parameters , NA )
vsl_param_set[["SAMPLE"]][["vsl"]] <- createValueList( config$vsl_information$parameters , config$convergence )

if ( !(POINT_MODE) ) {
  param_iter_data <- createParamIterData( vsl_param_set[["SAMPLE"]], config$convergence ) %>% select(-HIF)
  write_csv( param_iter_data, paste(OUT_FILE_NAME,"_param_iter.csv",sep="") )
}

if (DEBUG) { print(vsl_param_set[["POINT"]]) }
if (DEBUG) { print(vsl_param_set[["SAMPLE"]]) }
if (DEBUG) { print(param_iter_data) }

#---- Import and process the file ----------
indata <- read_csv(IN_FILE_NAME, progress=TRUE )

if (INCOME_YEAR=="FUTURE") {
  indata <- indata %>% mutate( YEAR_INC = YEAR_CLIM )
} else {
  indata <- indata %>% mutate( YEAR_INC = YEAR_POP ) 
}

out_file <- inner_join( indata , vsl_incgf_data, by=c("YEAR_INC")) 

if (DEBUG) { print(glimpse(out_file)) }

if (POINT_MODE) {

  if (DEBUG) { print("POINT") }
  
  out_file <- out_file %>%
    mutate( 
      VSL_PT = adjustVSLList(INCGF, vsl_param_set[["POINT"]], config$vsl_information$bls_cpi_factor),
      PDV_PT = applyVSL(YEAR_CLIM, CASES_PT, VSL_PT, DISCOUNT_YEAR, DISCOUNT_RATE)
    ) 
  
  
} else  {

  if (DEBUG) { print("NON-POINT") }
  
  out_file <- inner_join(out_file, param_iter_data, by="ITER" ) %>%
    mutate( 
      VSL_PT = adjustVSLList(INCGF, vsl_param_set[["POINT"]], config$vsl_information$bls_cpi_factor),
      PDV_PT = applyVSL(YEAR_CLIM, CASES_PT, VSL_PT, DISCOUNT_YEAR, DISCOUNT_RATE),
      VSL_ITER = adjustVSLCols(INCGF, refval_scale, refval_val, elas_scale, elas_val, config$vsl_information$bls_cpi_facto),
      PDV_ITER = applyVSL(YEAR_CLIM, CASES_ITER, VSL_ITER, DISCOUNT_YEAR, DISCOUNT_RATE)
    ) 
  
    
}

#---- Write output ----------

write_csv( out_file, OUT_FILE_NAME)


#------ Print summary ----------

DOLLAR_SCALE <- 1000000000 # Convert to billions

if (POINT_MODE) {

  summ <- out_file %>% group_by(HIF,MODEL) %>% summarise(pdv =  sum(PDV_PT) / DOLLAR_SCALE ) %>% ungroup() 
  
} else {
  
  summ <- out_file %>% group_by(HIF,MODEL,ITER) %>% summarise(pdv = sum(PDV_ITER) / DOLLAR_SCALE ) %>% ungroup() %>% 
    group_by(HIF,MODEL) %>% 
    summarise(MEAN = mean(pdv), 
              LCB = quantile(pdv,config$convergence$conv_quant$LCB), 
              UCB = quantile(pdv,config$convergence$conv_quant$UCB)  )  %>% 
    ungroup() %>%
    gather(stat,pdv,MEAN:UCB) 
  
}


print(summ %>% spread(HIF,pdv) )
